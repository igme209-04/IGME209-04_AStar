/// 
/// IGME-209.04 - Data Structures and Algorithms
/// 
/// Project 1           :  A* algorithm DLL for use in other programs
/// 
/// Class Description   : Some debugging exercises.
/// Created By          : Benjamin Kleynhans - bxk8027@rit.edu
///                       Adam McAree - arm1686@g.rit.edu
/// Date Created        : March 30, 2019
/// Last Modified By    : Benjamin Kleynhans
/// Date Modified       : March 30, 2019
/// Filename            : Graph.cpp
///

#include "stdafx.h"
#include "Graph.h"

// Default constructor
Graph::Graph()
{
	cout << "Default constructor not supported" << endl;
}

/*// Parameterized constructor
Graph::Graph(const int** maze, int& rows, int& columns)
{
	VertexList.clear();
	VisitedList.clear();
	this->adjMatrix = maze;
	this->SetColumns(columns);
	this->SetRows(rows);

	this->InstantiateVertices();

	cout << "Graph created" << endl;
}

void Graph::InstantiateVertices()
{
	for (int row = 0; row < this->GetRows(); row++)
	{
		for (int column = 0; column < this->GetColumns(); column++)
		{
			if (this->adjMatrix[row][column] == 0)
			{
				VertexList.push_back(new Vertex(row, column));
			}
		}
	}
}

void Graph::ResetSearchTree()
{

}

void Graph::ResetVisited()
{

}

void Graph::ShortestPath(int*)
{

}

void Graph::UpdateFinals(list<Vertex*> vertex)
{

}

void Graph::FindPath(int* origin, int* destination)
{

}

void Graph::SetColumns(const int columns)
{
	this->columns = columns;
}

int& Graph::GetColumns()
{
	return this->columns;
}

void Graph::SetRows(const int rows)
{
	this->rows = rows;
}

int& Graph::GetRows()
{
	return this->rows;
}

void Graph::DeleteVertices()
{
	Vertex* deleteMe;

	for (Vertex* vertex : VertexList)
	{
		deleteMe = vertex;
		VertexList.remove(vertex);
		delete(deleteMe);
	}
}*/

Graph::~Graph()
{
	//DeleteVertices();

	cout << "Graph destroyed" << endl;
}