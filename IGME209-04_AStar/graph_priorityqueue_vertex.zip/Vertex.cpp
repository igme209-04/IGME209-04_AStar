/// 
/// IGME-209.04 - Data Structures and Algorithms
/// 
/// Project 1           :  A* algorithm DLL for use in other programs
/// 
/// Class Description   : Some debugging exercises.
/// Created By          : Benjamin Kleynhans - bxk8027@rit.edu
///                       Adam McAree - arm1686@g.rit.edu
/// Date Created        : March 30, 2019
/// Last Modified By    : Benjamin Kleynhans
/// Date Modified       : March 30, 2019
/// Filename            : Vertex.cpp
///

#include "stdafx.h"
#include "Vertex.h"

// Default constructor
Vertex::Vertex()
{
	this->SetAddress(0, 0);

	cout << "Vertex created" << endl;
}

// Paramaterized constructor
Vertex::Vertex(int& x, int& y)
{
	this->SetAddress(x, y);
}

// Reset all properties of the vertex
void Vertex::Vertex::ResetVertex()
{
	this->Setfinal(false);
	this->SetFDistance(INT_MAX);
	this->SetGDistance(INT_MAX);
	this->SetHDistance(INT_MAX);
	this->SetNeighbor(nullptr);
}

// Reset the visited property of the vertex
void Vertex::Vertex::ResetVisited()
{
	this->SetVisited(false);
}

// All the getters and setters
void Vertex::SetAddress(int x, int y)
{
	this->address[0] = x;
	this->address[1] = y;
}

int* Vertex::GetAddress()
{
	return this->address;
}

void Vertex::SetFDistance(int totalDistance)
{
	this->fDistance = totalDistance;
}

int Vertex::GetFDistance()
{
	return this->fDistance;
}

void Vertex::SetGDistance(int distanceToOrigin)
{
	this->gDistance = distanceToOrigin;
}

int Vertex::GetGDistance()
{
	return this->gDistance;
}

void Vertex::SetHDistance(int distanceToDestination)
{
	this->hDistance = distanceToDestination;
}

int Vertex::GetHistance()
{
	return this->hDistance;
}

void Vertex::SetVisited(bool)
{
	this->visited = true;
}

bool Vertex::GetVisited()
{
	return this->visited;
}

void Vertex::Setfinal(bool)
{
	this->final = true;
}

bool Vertex::GetFinal()
{
	return this->final;
}

void Vertex::SetNeighbor(Vertex* pVertex)
{
	this->neighbor = pVertex;
}

Vertex* Vertex::GetNeighbor()
{
	return this->neighbor;
}

Vertex::~Vertex()
{
	cout << "Vertex destroyed" << endl;
}